#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*left;
    struct node*right;
}*root;
struct node*create(){
    int val;
    struct node*newnode;
    printf("To terminate enter the value -1\n");
    scanf("%d",&val);
    if(val==-1){
        return NULL;
    }
    newnode=(struct node*)malloc(sizeof(struct node));
    newnode->data=val;
    printf("Enter the left value of %d",val);
    newnode->left=create();
    printf("Enter the right value of %d",val);
    newnode->right=create();
    return newnode;
}
void inorder(struct node*root){
    if(root!=NULL){
        inorder(root->left);
        printf("%d",root->data);
        inorder(root->right);
    }
}
void preorder(struct node*root){
    if(root!=NULL){
        printf("%d",root->data);
        preorder(root->left);
        preorder(root->right);
    }
}
void postorder(struct node*root){
    if(root!=NULL){
        postorder(root->left);
        postorder(root->right);
        printf("%d",root->data);
    }
}
int height(struct node*root){
    if(root==NULL){
        return -1;
    }
    int lt=height(root->left);
    int rt=height(root->right);
    if(lt>rt){
        return lt+1;
    }
    else{
        return rt+1;
    }
}
void levelorder(struct node*root,int level){
    if(root==NULL){
        return NULL;
    }
    if(level==1){
        printf("%d",root->data);
    }
    if(level>1){
        levelorder(root->left,level-1);
        levelorder(root->right,level-1);
    }
    
}
int main(){
    root=create();
    printf("IN ORDER TRAVERSAL\n");
    inorder(root);
    printf("\nPRE ORDER TRAVERSAL\n");
    preorder(root);
    printf("\nPOST ORDER TRAVERSAL\n");
    postorder(root);
    int ht=height(root);
    printf("\nHeight of tree is%d \n",ht);
    printf("\nLevel Order Traversal is\n");
    for(int i=1;i<=ht+1;i++){
        levelorder(root,i);
    }
    return 0;
    
}
#include<stdio.h>
#include<stdlib.h>
struct node{
    int data;
    struct node*next;
}*top=NULL;
void push(int val){
    struct node*newnode;
    newnode=(struct node*)malloc(sizeof(struct node));
    newnode->data=val;
    if(top==NULL){
        newnode->next=NULL;
        top=newnode;
    }
    else{
        newnode->next=top;
        top=newnode;
    }
}
void display(){
    struct node*temp=top;
    while(temp!=NULL){
        printf("%d",temp->data);
        temp=temp->next;
    }
}
void pop(){
    struct  node*temm=top;
    printf("\n The deleted element is :%d",temm->data);
    temm=temm->next;
    printf("\n The elements in the stack are:\n");
    while(temm!=NULL){
        printf("%d\n",temm->data);
        temm=temm->next;
    }
}
void linear_search(int target){
    struct node*tem;
    tem=top;
    int flag=0;
    while(tem!=NULL){
        if(target==tem->data){
            printf("Element is found\n");
            flag=1;
        }
        tem=tem->next;
    }
    if(flag==0){
        printf("Element is not present in stack\n");
    }
    
}
void isempty(){
    if(top==NULL){
        printf("Stack is Empty\n");
    }
    else{
        printf("Stack is not empty\n");
    }
}
int main(){
    int i,n,value,Element;
    printf("Enter the no.of nodes\n");
    scanf("%d",&n);
    printf("Enter nodes\n");
    for(i=0;i<n;i++){
        scanf("%d",&value);
        push(value);
    }
    display();
    pop();
    isempty();
    scanf("%d",&Element);
    linear_search(Element);
    
}
